---
name: Mod Support Request
about: Request support for a specific mod
title: "[Mod Support Request] - EXAMPLE_MOD"
labels: request
assignees: ''

---

* Link to the mod page
* An estimate of the number of mobs introduced by the mod
* Game version + modloader (forge/fabric)
